package com.example.apptruyentranhh.object;

import java.io.Serializable;

public class Truyentranh  implements Serializable {
    private String tentruyen, tenchap, LinkAnh;

    public Truyentranh() {

    }

    public Truyentranh(String tentruyen, String tenchap, String linkAnh) {
        this.tentruyen = tentruyen;
        this.tenchap = tenchap;
        LinkAnh = linkAnh;
    }

    public String getTentruyen() {
        return tentruyen;
    }

    public void setTentruyen(String tentruyen) {
        this.tentruyen = tentruyen;
    }

    public String getTenchap() {
        return tenchap;
    }

    public void setTenchap(String tenchap) {
        this.tenchap = tenchap;
    }

    public String getLinkAnh() {
        return LinkAnh;
    }

    public void setLinkAnh(String linkAnh) {
        LinkAnh = linkAnh;
    }
}
