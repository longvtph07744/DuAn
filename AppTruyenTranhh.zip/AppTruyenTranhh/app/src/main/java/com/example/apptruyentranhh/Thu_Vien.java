package com.example.apptruyentranhh;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ViewFlipper;

import com.example.apptruyentranhh.adapter.TruyenTranh_Adapter;
import com.example.apptruyentranhh.object.Truyentranh;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class Thu_Vien extends AppCompatActivity {
    public ViewFlipper viewFlipper;
    GridView gdvdstruyen;
    ArrayList<Truyentranh> truyentranhArrayList;
    TruyenTranh_Adapter adapter_;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thu__vien);

        gdvdstruyen = findViewById(R.id.gdvDSTruyen);

        init();
        setup();
        setonclick();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    private void setonclick() {
    }

    private void setup() {
        gdvdstruyen.setAdapter(adapter_);

    }

    private void init() {
        truyentranhArrayList = new ArrayList<>();
        truyentranhArrayList.add(new Truyentranh("Bộ Thiên Ca", "Chapter 17", "https://3.bp.blogspot.com/-uKfnUKn4l1U/WBNE061U2pI/AAAAAAAAMlU/1w4WeeLfdJ0/hatsukoi-zombie.jpg"));
        truyentranhArrayList.add(new Truyentranh("Thiên thần ", "Chapter 5", "https://3.bp.blogspot.com/-22po55yUNXo/Wo9z08YchEI/AAAAAAAAP0M/HOo5VSjyXgs3YHLNPczvLJNH5OMlz6_NwCHMYCw/trai-tim-va-than-xac-blush-dc-himitsu"));
        truyentranhArrayList.add(new Truyentranh("Đường Tây Tử", "Chapter 6", "https://3.bp.blogspot.com/-KnV9VzReuA4/W03VRjCpdgI/AAAAAAAAXWE/4QTPZO7JLScg1FxB2ovSY3yiY1qnx7BRACHMYCw/tan-tac-long-ho-mon"));
        truyentranhArrayList.add(new Truyentranh("Tân Tác Long Hổ Môn", "Chapter 1016", "https://3.bp.blogspot.com/-fUUIZ4Fh0y4/Wo9nz9jZ3TI/AAAAAAAANi4/oJ28Retz8BYvLobtj3kZC1Qq9RtDoF5pwCHMYCw/vuong-tuoc-tu-huu-bao-boi"));
        truyentranhArrayList.add(new Truyentranh("Danh Môn Chí Ái", "Chapter 50.5", "https://3.bp.blogspot.com/-kgHjaI_K7GU/WqdkxteJZ3I/AAAAAAAARXI/ax6XxDzfl1kW-u88I4_GUDgUsi57OeyYwCHMYCw/nhan-chat-tinh-nhan"));
        truyentranhArrayList.add(new Truyentranh("Thú giữ nhà của đường Tây Tử", "Chapter 6", "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcROwDFDB-3phSsJs1zDLIN-eayOldP3nZO2TUwEB8_HhPJ6HagE&s"));
        truyentranhArrayList.add(new Truyentranh("Bộ Thiên Ca", "Chapter 17", "https://3.bp.blogspot.com/-U82kpymUB9w/V5ZMT6TLXjI/AAAAAAAAA6o/spbsT3lC2Ac/great-teacher-onizuka-paradise-lost.jpg"));
        truyentranhArrayList.add(new Truyentranh("Danh Môn Chí Ái", "Chapter 50.5", "https://3.bp.blogspot.com/-NPzw42KezrY/V5amCHSk6BI/AAAAAAAAD9k/KtS-cLK4bSg/pastel.jpg"));
        truyentranhArrayList.add(new Truyentranh("Tân Tác Long Hổ Môn", "Chapter 1016", "https://3.bp.blogspot.com/-KnV9VzReuA4/W03VRjCpdgI/AAAAAAAAXWE/4QTPZO7JLScg1FxB2ovSY3yiY1qnx7BRACHMYCw/tan-tac-long-ho-mon"));

        adapter_ = new TruyenTranh_Adapter(this, 0, truyentranhArrayList);


    }


    public void thuvien(View view) {
        Intent intent = new Intent(Thu_Vien.this, Thu_Vien.class);
        startActivity(intent);
    }

    public void theodoi(View view) {
        Intent intent = new Intent(Thu_Vien.this, TheoDoi.class);
        startActivity(intent);
    }

    public void home(View view) {
        Intent intent = new Intent(Thu_Vien.this, MainActivity.class);
        startActivity(intent);
    }

    public void lichsu(View view) {
        Intent intent = new Intent(Thu_Vien.this, Lich_Su.class);
        startActivity(intent);
    }


}
